extern const GeoLayout john_geo[];
extern Lights1 john_f3dlite_material_lights;
extern u8 john_john_ci4[];
extern u8 john_john_pal_rgba16[];
extern Vtx john_Bone_mesh_layer_1_vtx_0[4];
extern Gfx john_Bone_mesh_layer_1_tri_0[];
extern Gfx mat_john_f3dlite_material[];
extern Gfx mat_revert_john_f3dlite_material[];
extern Gfx john_Bone_mesh_layer_1[];
