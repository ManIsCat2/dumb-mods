Lights1 john_f3dlite_material_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFF, 0x49, 0x49, 0x49);

Gfx john_john_ci4_aligner[] = {gsSPEndDisplayList()};
u8 john_john_ci4[] = {
	#include "actors/john/john.ci4.inc.c"
};

Gfx john_john_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 john_john_pal_rgba16[] = {
	#include "actors/john/john.rgba16.pal"
};

Vtx john_Bone_mesh_layer_1_vtx_0[4] = {
	{{ {-213, -17, 0}, 0, {-16, 1008}, {0, 0, 127, 255} }},
	{{ {213, -17, 0}, 0, {752, 1008}, {0, 0, 127, 255} }},
	{{ {213, 409, 0}, 0, {752, -16}, {0, 0, 127, 255} }},
	{{ {-213, 409, 0}, 0, {-16, -16}, {0, 0, 127, 255} }},
};

Gfx john_Bone_mesh_layer_1_tri_0[] = {
	gsSPVertex(john_Bone_mesh_layer_1_vtx_0 + 0, 4, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 2, 3, 0),
	gsSPEndDisplayList(),
};


Gfx mat_john_f3dlite_material[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetTextureLUT(G_TT_RGBA16),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(john_f3dlite_material_lights),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 1, john_john_pal_rgba16),
	gsDPSetTile(0, 0, 0, 256, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTLUTCmd(5, 3),
	gsDPSetTextureImage(G_IM_FMT_CI, G_IM_SIZ_8b, 12, john_john_ci4),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b, 2, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTile(7, 0, 0, 46, 124),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_4b, 2, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 92, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_john_f3dlite_material[] = {
	gsDPPipeSync(),
	gsDPSetTextureLUT(G_TT_NONE),
	gsSPEndDisplayList(),
};

Gfx john_Bone_mesh_layer_1[] = {
	gsSPDisplayList(mat_john_f3dlite_material),
	gsSPDisplayList(john_Bone_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_john_f3dlite_material),
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

