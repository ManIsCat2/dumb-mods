-- name: Block mod

local ON_GRID = true
local GRID_SIZE = 200

local function to_grid(n)
	if ON_GRID then
		return math.floor(n / GRID_SIZE + .5) * GRID_SIZE
	else
		return n
	end
end

--outline place
function bhv_outlineblock_init(obj)
	obj.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
	cur_obj_scale(4.01)
	obj.oOpacity = 255
	obj.oFaceAnglePitch = 0
	obj.oFaceAngleYaw = 0
	obj.oFaceAngleRoll = 0
end

id_bhvOutlineblock = hook_behavior(nil, OBJ_LIST_DEFAULT, true, bhv_outlineblock_init, nil)

function find_place()
	local obj = obj_get_first(OBJ_LIST_DEFAULT)
	while obj ~= nil do
		if get_id_from_behavior(obj.behavior) == id_bhvOutlineblock then
			return obj
		end
		obj = obj_get_next(obj)
	end
	return nil
end

local place

function place_block(x, y, z)
	local box = spawn_sync_object(
		ggbhv,
		E_MODEL_BREAKABLE_BOX,
		x, y, z,
		function(obj)
			obj.oOpacity = 255
			obj.oFaceAnglePitch = 0
			obj.oFaceAngleYaw = 0
			obj.oFaceAngleRoll = 0
		end
	)

	play_sound(SOUND_GENERAL_BOX_LANDING, { x = x, y = y, z = z })
end

function mario_update_local(m)
	local rgt = math.sin(m.intendedYaw / 32688 * math.pi) --idk the max angle value so i just went with this
	local fwd = math.cos(m.intendedYaw / 32688 * math.pi)

	local in_air = m.pos.y - m.floorHeight > 5
	local crouching = (m.controller.buttonDown & Z_TRIG) ~= 0
	local posX = to_grid(m.pos.x + (in_air and 0 or rgt * GRID_SIZE))
	local posY = to_grid(m.pos.y + ((in_air or crouching) and -GRID_SIZE or 0))
	local posZ = to_grid(m.pos.z + (in_air and 0 or fwd * GRID_SIZE))

	--update outline box pos
	


	--place block
	if (m.controller.buttonPressed & Y_BUTTON) ~= 0 then
		place_block(posX, posY, posZ)
	end
end

function on_warp()
	if place then
		obj_mark_for_deletion(place)
	end
end

function mario_update(m)
	if m.playerIndex == 0 then
		mario_update_local(m)
	end
end

function bhv_thing_init(o)
	o.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_MOVE_XZ_USING_FVEL
	o.oGravity = 3
	o.oFriction = 1
	o.hitboxHeight = 400
	o.hitboxRadius = 400
	o.oIntangibleTimer = 0
	o.collisionData = gGlobalObjectCollisionData.breakable_box_seg8_collision_08012D70
	network_init_object(o, true, nil)
end

function bhv_thing_loop(o)
	load_object_collision_model(
	)
	m = gMarioStates[0]

	if m.controller.buttonPressed & X_BUTTON ~= 0 then
		o.oForwardVel = o.oForwardVel ~20
	end
	if grav then
		object_step()
	end

end

ggbhv = hook_behavior(nil, OBJ_LIST_SURFACE, true, bhv_thing_init, bhv_thing_loop)

--[[function john_init(o)
	o.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_MOVE_XZ_USING_FVEL
	o.oGravity = 3
	o.oFriction = 1
	o.oIntangibleTimer = 0
	o.oSubAction = 1600
	obj_set_billboard(o)
	obj_set_model_extended(o, smlua_model_util_get_id("john_geo"))
	network_init_object(o, true, nil)
end

function john_loop(o)
	m = gMarioStates[0]
	o.oSubAction = o.oSubAction - (30 - m.forwardVel)
	local distance = -o.oSubAction -- negative distance to go behind Mario
	local angleRad = math.rad(m.faceAngle.y)
	o.oPosX = m.pos.x + (distance * math.sin(angleRad))
	o.oPosZ = m.pos.z - (distance * math.cos(angleRad))
	o.oPosY = m.floorHeight
	if obj_check_hitbox_overlap(o, m.marioObj) then
		m.health = 0xff
		obj_mark_for_deletion(o)
	end
end

john = hook_behavior(nil, OBJ_LIST_GENACTOR, true, john_init, john_loop)]]

hook_event(HOOK_ON_WARP, on_warp)
hook_event(HOOK_MARIO_UPDATE, mario_update)
